/* global document, Office, Excel */

Office.onReady((info) => {
  if (info.host === Office.HostType.Excel) {
    document.getElementById("get-selection")!.onclick = getSelection;
    document.getElementById("set-values")!.onclick = setValues;
    document.getElementById("highlight")!.onclick = highlightSelection;
  }
});

function log(message: string): void {
  const out = document.getElementById("output")!;
  out.textContent = message;
}

async function getSelection(): Promise<void> {
  try {
    await Excel.run(async (context) => {
      const range = context.workbook.getSelectedRange();
      range.load("address, values");
      await context.sync();
      log(`Address: ${range.address}\nValues: ${JSON.stringify(range.values)}`);
    });
  } catch (error) {
    log(`Error: ${error}`);
  }
}

async function setValues(): Promise<void> {
  try {
    await Excel.run(async (context) => {
      const range = context.workbook.getSelectedRange();
      range.values = [
        ["Name", "Score"],
        ["Alice", 92],
        ["Bob", 87]
      ];
      range.format.autofitColumns();
      await context.sync();
      log("Sample data written.");
    });
  } catch (error) {
    log(`Error: ${error}`);
  }
}

async function highlightSelection(): Promise<void> {
  try {
    await Excel.run(async (context) => {
      const range = context.workbook.getSelectedRange();
      range.format.fill.color = "#FFEB3B";
      await context.sync();
      log("Selection highlighted.");
    });
  } catch (error) {
    log(`Error: ${error}`);
  }
}
