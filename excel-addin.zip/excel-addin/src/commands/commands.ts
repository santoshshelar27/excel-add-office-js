/* global Office, Excel */

Office.onReady(() => {
  // Nothing to initialize here; handlers register themselves below.
});

/**
 * Runs when the ribbon button "Highlight Selection" is clicked.
 * Must be associated with the FunctionName set in manifest.xml.
 */
function highlightSelectionAction(event: Office.AddinCommands.Event): void {
  Excel.run(async (context) => {
    const range = context.workbook.getSelectedRange();
    range.format.fill.color = "#FFEB3B";
    await context.sync();
  })
    .catch((error) => {
      console.error(error);
    })
    .finally(() => {
      event.completed();
    });
}

/**
 * Runs when the ribbon button "Insert Timestamp" is clicked.
 */
function insertTimestampAction(event: Office.AddinCommands.Event): void {
  Excel.run(async (context) => {
    const range = context.workbook.getSelectedRange();
    range.values = [[new Date().toLocaleString()]];
    await context.sync();
  })
    .catch((error) => {
      console.error(error);
    })
    .finally(() => {
      event.completed();
    });
}

Office.actions.associate("highlightSelectionAction", highlightSelectionAction);
Office.actions.associate("insertTimestampAction", insertTimestampAction);
