/* global CustomFunctions, OfficeRuntime */

/**
 * Doubles a number.
 * @customfunction
 * @param value Number to double.
 * @returns Doubled value.
 */
export function double(value: number): number {
  return value * 2;
}

/**
 * Adds two numbers.
 * @customfunction
 * @param a First number.
 * @param b Second number.
 * @returns Sum of a and b.
 */
export function add(a: number, b: number): number {
  return a + b;
}

/**
 * Returns the current timestamp. Marked volatile so it recalculates
 * whenever the workbook recalculates.
 * @customfunction
 * @returns Current date/time as a string.
 */
export function now(): string {
  return new Date().toLocaleString();
}

/**
 * Fetches a value from a public API and returns it. Demonstrates an
 * async, streaming-capable custom function.
 * @customfunction
 * @param city City name.
 * @param invocation Custom function handler.
 */
export function getTemperature(
  city: string,
  invocation: CustomFunctions.StreamingInvocation<string>
): void {
  // Example pattern for an async / streaming function.
  // Replace with a real API call as needed.
  const interval = setInterval(() => {
    const fakeTemp = (15 + Math.random() * 10).toFixed(1);
    invocation.setResult(`${fakeTemp}°C in ${city}`);
  }, 5000);

  invocation.onCanceled = () => {
    clearInterval(interval);
  };
}
