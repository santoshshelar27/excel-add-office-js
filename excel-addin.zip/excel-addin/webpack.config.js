const path = require("path");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const CopyWebpackPlugin = require("copy-webpack-plugin");

const urlDev = "https://localhost:3000/";
const urlProd = "https://YOUR-DEPLOYED-DOMAIN.com/"; // update when you deploy

module.exports = (env, options) => {
  const dev = options.mode === "development";

  return {
    devtool: "source-map",
    entry: {
      taskpane: "./src/taskpane/taskpane.ts",
      commands: "./src/commands/commands.ts",
      functions: "./src/functions/functions.ts"
    },
    output: {
      clean: true,
      path: path.resolve(__dirname, "dist"),
      filename: "[name].js"
    },
    resolve: {
      extensions: [".ts", ".js"]
    },
    module: {
      rules: [
        {
          test: /\.ts$/,
          use: "ts-loader",
          exclude: /node_modules/
        }
      ]
    },
    plugins: [
      new HtmlWebpackPlugin({
        filename: "taskpane.html",
        template: "./src/taskpane/taskpane.html",
        chunks: ["taskpane"]
      }),
      new HtmlWebpackPlugin({
        filename: "commands.html",
        template: "./src/commands/commands.html",
        chunks: ["commands"]
      }),
      new HtmlWebpackPlugin({
        filename: "functions.html",
        template: "./src/functions/functions.html",
        chunks: ["functions"]
      }),
      new CopyWebpackPlugin({
        patterns: [
          { from: "assets", to: "assets", noErrorOnMissing: true },
          { from: "src/functions/functions.json", to: "functions.json" },
          {
            from: "manifest.xml",
            to: "manifest.xml",
            transform(content) {
              return dev
                ? content
                : content.toString().split(urlDev).join(urlProd);
            }
          }
        ]
      })
    ],
    devServer: {
      static: path.resolve(__dirname, "dist"),
      server: "https", // requires office-addin-dev-certs
      port: 3000,
      hot: true,
      headers: {
        "Access-Control-Allow-Origin": "*"
      }
    }
  };
};
