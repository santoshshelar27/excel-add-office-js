# Excel Add-in (Vanilla TypeScript)

Custom functions + ribbon commands + task pane, no framework.

## Structure
```
manifest.xml              → wires everything together
src/taskpane/              → sidebar UI (taskpane.html/ts/css)
src/commands/               → ribbon button handlers (commands.html/ts)
src/functions/               → custom functions (functions.ts) + metadata (functions.json) + host page (functions.html)
webpack.config.js
```

## Setup
```bash
cd excel-addin
npm install
npx office-addin-dev-certs install    # trusts a local HTTPS cert, required by Office
```

## Run / sideload
```bash
npm run dev-server     # starts https://localhost:3000
npm start               # in a second terminal: sideloads manifest.xml into Excel
```
`npm start` uses `office-addin-debugging`, which opens Excel (desktop or online, whichever you configure) with the add-in already sideloaded. Stop with `npm run stop`.

If you'd rather sideload manually: Excel → Insert → My Add-ins → Upload My Add-in → select `manifest.xml` (dev server must be running).

## Regenerating functions.json
I hand-wrote `functions.json` to match `functions.ts` so the project runs without an extra build step. Once you add/change custom functions, regenerate it properly instead of hand-editing:
```bash
npm run generate-functions-metadata
```
This parses the `@customfunction` JSDoc in `functions.ts` and rebuilds the metadata file. Do this every time you change a function's signature.

## What's wired up

**Taskpane** — three buttons: read selected range, write sample data, highlight selection. All via `Excel.run`.

**Ribbon (commands.ts)** — two buttons registered directly on the Home tab ("Highlight", "Insert Timestamp") that run without opening the task pane, via `Office.actions.associate`.

**Custom functions (functions.ts)**, usable in any cell once sideloaded, under the `CONTOSO` namespace (change `Functions.Namespace` in manifest.xml to your own):
- `=CONTOSO.DOUBLE(5)` → 10
- `=CONTOSO.ADD(2,3)` → 5
- `=CONTOSO.NOW2()` → current timestamp (named `NOW2` since `NOW` is a reserved Excel function)
- `=CONTOSO.GETTEMPERATURE("London")` → streaming function, updates every 5s (swap the fake data for a real fetch)

## Before shipping
- Replace the `Id` GUID in manifest.xml with a fresh one (`npx office-addin-manifest info` or any GUID generator).
- Replace `https://localhost:3000` everywhere in manifest.xml with your production HTTPS domain, and update `urlProd` in webpack.config.js.
- Replace the placeholder icons in `/assets` with real ones (16/32/64/80 px PNGs).
- Run `npm run validate` to lint the manifest before submitting to AppSource or deploying internally.
